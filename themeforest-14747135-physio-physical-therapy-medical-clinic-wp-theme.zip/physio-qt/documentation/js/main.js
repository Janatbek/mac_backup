$('#nav').affix({
      offset: {
        top: 600,
      }
});

$('body').scrollspy({
    target: '#nav'
});